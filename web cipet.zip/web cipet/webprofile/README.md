# Praktikum2
# Praktikum2
# Praktikum-2
